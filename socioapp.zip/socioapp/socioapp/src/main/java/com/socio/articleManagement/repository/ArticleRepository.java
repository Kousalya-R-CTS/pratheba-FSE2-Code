package com.socio.articleManagement.repository;

import java.util.ArrayList;
import java.util.List;

import com.socio.articleManagement.exception.BaseClassException;
import com.socio.articleManagement.models.ArticleStatusResponseDB;
import com.socio.articleManagement.models.ReplyArticle;
import com.socio.articleManagement.models.ReplyArticles;
import com.socio.articleManagement.util.SocioAppConstants;
import com.socio.articleManagement.util.SocioAppServiceUtil;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mongodb.client.result.DeleteResult;

/**
 * class ArticleRepository
 *
 */
@Repository
public class ArticleRepository {
	@Autowired
	ObjectMapper objectMapper;
	@Autowired
	private MongoTemplate mongoTemplate;
	/**
	 * logger for logging data
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(ArticleRepository.class);

	/**
	 * default constructor
	 */
	public ArticleRepository() {
		super();
	}



	/**
	 * method deleteArticle - to delete article from DB
	 * @param id - id 
	 * @return boolean - result
	 * @throws BaseClassException - exception
	 */
	public boolean deleteArticle(String id, String userName) throws BaseClassException{
		LOGGER.info("deleteArticle() api is invoked");
		boolean isDeleted = false;
		try
		{
			ArticleStatusResponseDB article = getArticleDetailById(id);
			//delete is only applicable if logged in user is matched with article to be deleted
			if(userName.equalsIgnoreCase(article.getAuthorUserName()))
			{
			/**
			 * If article has reply article, then delete the reply article by using thread id
			 */
			if (null != article.getReplyArticles()) {
				Query query = extractReplyArticles(article);
				// Remove all reply article as a single article in collection
				mongoTemplate.findAllAndRemove(query, ArticleStatusResponseDB.class, "article_detail");

			}
			/**
			 * If articleType is Reply, then update original article with that removed reply id
			 */
			if (SocioAppConstants.REPLY.equalsIgnoreCase(article.getArticleType())) {
				ArticleStatusResponseDB threadArticle = extractedOriginalArticle(article);
				ReplyArticles replyArticlesDb = threadArticle.getReplyArticles();
				replyArticlesDb.setReplyCount(replyArticlesDb.getReplyCount() - SocioAppConstants.NUM1);
				List<ReplyArticle> replyList = replyArticlesDb.getReplyArticleList();
				replyList
						.removeIf((ReplyArticle replyArticle) -> replyArticle.getThreadId().equalsIgnoreCase(article.getArticleId()));
				replyArticlesDb.setReplyArticleList(replyList);
				threadArticle.setReplyArticles(replyArticlesDb);
				threadArticle.setUpdatedAt(SocioAppServiceUtil.getCurrentDate());
				mongoTemplate.save(threadArticle);
			}
			DeleteResult result = mongoTemplate.remove(article, "article_detail");
			if (result.getDeletedCount() == SocioAppConstants.NUM1) {
				isDeleted = true;
			}
			}
		}
			catch (Exception e) {
				// Exception handling
				LOGGER.error(SocioAppConstants.API_ERROR, ExceptionUtils.getStackTrace(e));
				
			}
			LOGGER.info("deleteArticle() api is invoked");
		return isDeleted;
	}

	/**
	 * @param article
	 * @return
	 */
	public ArticleStatusResponseDB extractedOriginalArticle(ArticleStatusResponseDB article) {
		Query query2 = new Query();
		query2.addCriteria(Criteria.where("replyArticles.replyArticles.threadId").in(article.getArticleId()));
		ArticleStatusResponseDB threadArticle = mongoTemplate.findOne(query2, ArticleStatusResponseDB.class,
				"article_detail");
		return threadArticle;
	}

	/**
	 * @param id
	 * @return
	 */
	public ArticleStatusResponseDB getArticleDetailById(String id) {
		Query query1 = new Query(Criteria.where("articleId").is(id));
		ArticleStatusResponseDB article = mongoTemplate.findOne(query1, ArticleStatusResponseDB.class);
		return article;
	}

	/**
	 * @param article
	 * @return
	 */
	public Query extractReplyArticles(ArticleStatusResponseDB article) {
		List<ReplyArticle> articleList = article.getReplyArticles().getReplyArticleList();
		// For Delete reply articles incase reply article is deleted
		List<String> replyArticleList = new ArrayList<String>();
		articleList.forEach((ReplyArticle reply) -> {
			replyArticleList.add(reply.getThreadId());
		});
		Query query = new Query();
		query.addCriteria(Criteria.where("articleId").in(replyArticleList));
		return query;
	}
	/**
	 * method getUserArticles - to get user articles
	 * @param id - id
	 * @param name - name
	 * @param threadId - threadId
	 * @return List<ArticleStatusResponseDB> - list
	 */
	public List<ArticleStatusResponseDB> getUserArticles(String id, String name, String threadId) {
		List<ArticleStatusResponseDB> result = null;
		ArticleStatusResponseDB originalArticle = new ArticleStatusResponseDB();
		Query query = new Query();
		if(null != id)
		{
			ArticleStatusResponseDB article = getArticleDetailById(id);
			if(null != article.getReplyArticles())
			{
				query = extractReplyArticles(article);
				
				result = mongoTemplate.find(query, ArticleStatusResponseDB.class, "article_detail");
			}
			
		}
		else
		{
			List<String> mentionUserName = new ArrayList<>();
			mentionUserName.add(name);
			query = new Query(Criteria.where("authorUserName").in(mentionUserName)).with(Sort.by(Sort.Direction.DESC, "createdAt").and(Sort.by(Sort.Direction.DESC, "updatedAt")));
			result = mongoTemplate.find(query, ArticleStatusResponseDB.class, "article_detail");
		}
		if(null != threadId)
		{
			
			originalArticle.setArticleId(threadId);
			originalArticle = extractedOriginalArticle(originalArticle);
			originalArticle.setEventType("ORIGIN");
			result.add(originalArticle);
		}
		
		
		return result;
	}
}
