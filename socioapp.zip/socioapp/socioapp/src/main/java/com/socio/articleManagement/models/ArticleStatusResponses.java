package com.socio.articleManagement.models;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"metaData", "articles"})
public class ArticleStatusResponses {
    @JsonProperty("metaData")
    private MetaData metaData;
    @JsonProperty("articles")
    private List<ArticleStatusResponseDB> articles;

    /**
     * No args constructor for use in serialization
     * 
     */
    public ArticleStatusResponses()
    {
    	//constructor
    }

	/**
	 * @return the metaData
	 */
	@JsonProperty("metaData")
	public MetaData getMetaData() {
		return metaData;
	}

	/**
	 * @param metaData the metaData to set
	 */
	@JsonProperty("metaData")
	public void setMetaData(MetaData metaData) {
		this.metaData = metaData;
	}

	/**
	 * @return the articles
	 */
	@JsonProperty("articles")
	public List<ArticleStatusResponseDB> getArticles() {
		return articles;
	}

	/**
	 * @param articles the articles to set
	 */
	@JsonProperty("articles")
	public void setArticles(List<ArticleStatusResponseDB> articles) {
		this.articles = articles;
	}
	

}
