package com.socio.articleManagement.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.socio.articleManagement.models.RegistrationData;

/**
 * class UserRepository
 *
 */
@Repository
public interface UserOperationRepository extends MongoRepository<RegistrationData, String>
{
	@Query("{'loginId': {'$regex':?0 , '$options':'i'}}")
	List<RegistrationData> searchUserByEmail(String loginId) ;
}
