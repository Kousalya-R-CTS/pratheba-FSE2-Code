package com.socio.articleManagement.models;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
/**
 * @author User
 *
 */
@Document(collection = "user_detail")
public class RegistrationData {
	@Id
	public String id;
	/**
	 * field description
	 */
	private String firstName;
	/**
	 * field description
	 */
	private String lastName;
	/**
	 * field description
	 */
	private String loginId;
	/**
	 * field description
	 */
	private String contactNumber;
	/**
	 * field description
	 */
	private String email;
	/**
	 * field description
	 */
	private String password;
	/**
	 * field description
	 */
	private String status;
	/**
	 * field description
	 */
	private String loginTime;
	/**
	 * field description
	 */
	private String logoutTime;
	/**
	 * default constructor
	 */
	public RegistrationData()
	{
		super();
	}
	
	public RegistrationData(Registration registration) {
		this.firstName = registration.getFirst_name();
		this.lastName = registration.getLast_name();
		this.loginId = registration.getLogin_id();
		this.contactNumber = registration.getContact_number();
		this.email = registration.getEmail();
		this.password = registration.getPassword();
		this.status = registration.getStatus();
		this.loginTime = registration.getLogin_time();
		this.logoutTime = registration.getLogoutTime();
	}

	/**
	 * method description
	 */
	public String getFirstName() {
		return firstName;
	}
	/**
	 * method description
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	/**
	 * method description
	 */
	public String getLastName() {
		return lastName;
	}
	/**
	 * method description
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	/**
	 * method description
	 */
	public String getLoginId() {
		return loginId;
	}
	/**
	 * method description
	 */
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	/**
	 * method description
	 */
	public String getContactNumber() {
		return contactNumber;
	}
	/**
	 * method description
	 */
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	/**
	 * method description
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * method description
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	/**
	 * method description
	 */
	public String getPassword() {
		return password;
	}
	/**
	 * method description
	 */
	public void setPassword(String password) {
		this.password = password;
	}
	/**
	 * method description
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * method description
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * method description
	 */
	public String getLoginTime() {
		return loginTime;
	}
	/**
	 * method description
	 */
	public void setLoginTime(String loginTime) {
		this.loginTime = loginTime;
	}
	/**
	 * method description
	 */
	public String getLogoutTime() {
		return logoutTime;
	}
	/**
	 * method description
	 */
	public void setLogoutTime(String logoutTime) {
		this.logoutTime = logoutTime;
	}

}
