/**
 * 
 */
package com.socio.articleManagement.exception;

import com.socio.articleManagement.util.SocioAppConstants;

/**
 * @author User
 *
 */
public class BaseClassException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * method description
	 */
	public BaseClassException(String errorCode, String errorMessage,
			String errorOrigin, Exception exception)
	{
		super("Error occured in" + errorOrigin + "with Error code"+ errorCode + SocioAppConstants.ERROR_DETAILS + errorMessage,exception);
	}
	/**
	 * method description
	 */
	public BaseClassException(Exception exception) {
		super(SocioAppConstants.ERROR_DETAILS + exception);
	}
	/**
	 * method description
	 */
	public BaseClassException(String errorCode, String errorMessage)
			
	{
		super("Error code"+ errorCode + SocioAppConstants.ERROR_DETAILS + errorMessage);
	}
	/**
	 * method description
	 */
	public BaseClassException(String errorMessage)
	{
		super(SocioAppConstants.ERROR_DETAILS + errorMessage);
	}

}
