
package com.socio.articleManagement.models;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class FavouriteArticles {

    @JsonProperty("favouriteCount")
    private int favouriteCount;
    @JsonProperty("favouriteArticleList")
    private List<FavouriteArticle> favouriteArticles;
    
    /**
     * No args constructor for use in serialization
     * 
     */
    public FavouriteArticles() {
    	//Default Constructor
    }

	/**
	 * @return the favouriteCount
	 */
	@JsonProperty("favouriteCount")
	public int getFavouriteCount() {
		return favouriteCount;
	}

	/**
	 * @param favouriteCount the favouriteCount to set
	 */
	@JsonProperty("favouriteCount")
	public void setFavouriteCount(int favouriteCount) {
		this.favouriteCount = favouriteCount;
	}

	/**
	 * @return the favouriteArticleList
	 */
	@JsonProperty("favouriteArticleList")
	public List<FavouriteArticle> getFavouriteArticleList() {
		return favouriteArticles;
	}

	/**
	 * @param favouriteArticleList the favouriteArticleList to set
	 */
	@JsonProperty("favouriteArticleList")
	public void setFavouriteArticleList(List<FavouriteArticle> favouriteArticleList) {
		this.favouriteArticles = favouriteArticleList;
	}

	
	
}
