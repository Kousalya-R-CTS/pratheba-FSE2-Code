
package com.socio.articleManagement.models;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class FavouriteArticle {

    @JsonProperty("createdAt")
    private String createdAt;
    @JsonProperty("favouriteAt")
    private String favouriteAt;
    @JsonProperty("isLike")
    private boolean isLike;
    @JsonProperty("id")
    private long id;
    @JsonProperty("articleId")
    private String articleId;
    @JsonProperty("favouriteUserName")
    private String favouriteUserName;
    
    /**
     * No args constructor for use in serialization
     * 
     */
    public FavouriteArticle() {
    }

	public FavouriteArticle(String createdAt, String favouriteAt, boolean isLike, long id, String articleId,
							String favouriteUserName) {
		super();
		this.createdAt = createdAt;
		this.favouriteAt = favouriteAt;
		this.isLike = isLike;
		this.id = id;
		this.articleId = articleId;
		this.favouriteUserName = favouriteUserName;
	}

	/**
	 * @return the createdAt
	 */
	@JsonProperty("createdAt")
	public String getCreatedAt() {
		return createdAt;
	}

	/**
	 * @param createdAt the createdAt to set
	 */
	@JsonProperty("createdAt")
	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}

	/**
	 * @return the favouriteAt
	 */
	@JsonProperty("favouriteAt")
	public String getFavouriteAt() {
		return favouriteAt;
	}

	/**
	 * @param favouriteAt the favouriteAt to set
	 */
	@JsonProperty("favouriteAt")
	public void setFavouriteAt(String favouriteAt) {
		this.favouriteAt = favouriteAt;
	}

	/**
	 * @return the isLike
	 */
	@JsonProperty("isLike")
	public boolean isLike() {
		return isLike;
	}

	/**
	 * @param isLike the isLike to set
	 */
	@JsonProperty("isLike")
	public void setLike(boolean isLike) {
		this.isLike = isLike;
	}

	/**
	 * @return the id
	 */
	@JsonProperty("id")
	public long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	@JsonProperty("id")
	public void setId(long id) {
		this.id = id;
	}

	/**
	 * @return the articleId
	 */
	@JsonProperty("articleId")
	public String getArticleId() {
		return articleId;
	}

	/**
	 * @param articleId the articleId to set
	 */
	@JsonProperty("articleId")
	public void setArticleId(String articleId) {
		this.articleId = articleId;
	}

	/**
	 * @return the favouriteUserName
	 */
	@JsonProperty("favouriteUserName")
	public String getFavouriteUserName() {
		return favouriteUserName;
	}

	/**
	 * @param favouriteUserName the favouriteUserName to set
	 */
	@JsonProperty("favouriteUserName")
	public void setFavouriteUserName(String favouriteUserName) {
		this.favouriteUserName = favouriteUserName;
	}
    
   
}
