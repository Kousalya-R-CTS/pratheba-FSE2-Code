package com.socio.articleManagement.service;

import com.socio.articleManagement.exception.BaseClassException;
import com.socio.articleManagement.models.Registration;
import com.socio.articleManagement.models.RegistrationData;

/**
 * Interface IUserService
 *
 */
public interface IUserService 
{
	/**
	 * method saveUser
	 */
	RegistrationData saveUser(Registration registration) throws BaseClassException;

	/**
	 * method updateUser
	 * @param registration - registration
	 * @return RegistrationData - RegistrationData
	 */
	RegistrationData updateUser(Registration registration) throws BaseClassException;

	RegistrationData getLoginStatus(String name, String password) throws BaseClassException;
}
