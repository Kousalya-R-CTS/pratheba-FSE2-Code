package com.socio.articleManagement.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.socio.articleManagement.exception.BaseClassException;
import com.socio.articleManagement.models.Registration;
import com.socio.articleManagement.models.RegistrationData;
import com.socio.articleManagement.repository.UserRepository;
import com.socio.articleManagement.service.IUserService;

/**
 * class UserServiceImpl implements IUSerService
 *
 */
@Service
public class UserServiceImpl implements IUserService
{
	
	/**
	 * holds userRepository reference
	 */
	@Autowired
	private UserRepository userRepository;
	/**
	 * default constructor
	 */
	public UserServiceImpl() {
		super();
	}
	/**
	 * method saveUser
	 * @param Registration - registration
	 * @return Registration - registration
	 * @throws BaseClassException - exception
	 */
	@Override
	public RegistrationData saveUser(Registration registration) throws BaseClassException {
		
		return userRepository.saveUser(registration);
	}
	/**
	 * method updateUser
	 */
	@Override
	public RegistrationData updateUser(Registration registration) throws BaseClassException {
		return userRepository.updateUser(registration);
	}
	@Override
	public RegistrationData getLoginStatus(String name, String password) throws BaseClassException {
		return userRepository.getLoginStatus(name, password);
	}

}
