
package com.socio.articleManagement.webservices;


import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import com.socio.articleManagement.util.SocioAppConstants;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.socio.articleManagement.exception.BaseClassException;
import com.socio.articleManagement.models.Registration;
import com.socio.articleManagement.models.RegistrationData;
import com.socio.articleManagement.models.ResponseGateway;
import com.socio.articleManagement.repository.UserOperationRepository;
import com.socio.articleManagement.service.IUserService;

/**
 * @author User
 *
 */
@RestController
@EnableAutoConfiguration
@CrossOrigin(origins = "*")
public class UserController 
{
	/**
	 * logger for logging data
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(UserController.class);
	
	/**
	 * holds UserService reference
	 */
	@Autowired
	private IUserService userService;
	/**
	 * holds UserService reference
	 */
	@Autowired
	private UserOperationRepository userOperationRepository;
	/**
	 * default constructor
	 */
	public UserController() {
		super();
	}
	
	
	/**
	 * @param userService the userService to set
	 */
	public void setUserService(IUserService userService) {
		this.userService = userService;
	}

	/**
	 * method create user - to create user in DB
	 * @param registration - registration
	 * @param httpServletResponse - httpServletResponse
	 * @return response - response
	 * @throws BaseClassException - exception
	 */
	@RequestMapping(value="/register", method= RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseGateway> createUser(@RequestBody Registration registration, 
			HttpServletResponse httpServletResponse) throws BaseClassException
	{
		LOGGER.info("createUser() api is invoked");
		ResponseGateway gateway = new ResponseGateway();
		ResponseEntity<ResponseGateway> responseGateway = null;
		List<String> error = new ArrayList<>();
		RegistrationData response = null;
		try
		{
		  response = userService.saveUser(registration);
		if(null != response)
		{
			responseGateway = gateway.buildResponse(response, "", "200");
		}
		else
		{
			error.add("No records");
			responseGateway = gateway.buildResponse(error, "", "200");
		}
		}
		catch(Exception e)
		{
		 //Exception handling
		 LOGGER.error(SocioAppConstants.API_ERROR, ExceptionUtils.getStackTrace(e));
		}
		LOGGER.info("Exit: createUser()");
		return responseGateway;
	}
	@RequestMapping(value="/users/all", method= RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseGateway> searchUsers(
			
			HttpServletResponse httpServletResponse) throws BaseClassException
	{
		LOGGER.info("createUser() api is invoked");
		ResponseGateway gateway = new ResponseGateway();
		ResponseEntity<ResponseGateway> responseGateway = null;
		List<String> error = new ArrayList<>();
		List<String> userName = new ArrayList<>();
		List<RegistrationData> resp = null;
		try
		{
			resp = userOperationRepository.findAll();
			
		
		if(null != resp)
		{
			resp.forEach((RegistrationData data) -> userName.add(data.getLoginId()));
			responseGateway = gateway.buildResponse(userName, "", "200");
		}
		else
		{
			error.add("user not created");
			responseGateway = gateway.buildResponse(error, "", "200");
		}
		}	
		catch(Exception e)
		{
		 //Exception handling
		 LOGGER.error(SocioAppConstants.API_ERROR, ExceptionUtils.getStackTrace(e));
		}
		LOGGER.info("Exit: createUser()");
		return responseGateway;
	}
	@RequestMapping(value="/login", method= RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseGateway> getLoginStatus(
			@RequestParam String userName, @RequestParam String password,
			HttpServletResponse httpServletResponse) throws BaseClassException
	{
		LOGGER.info("getLoginStatus() api is invoked");
		ResponseGateway gateway = new ResponseGateway();
		ResponseEntity<ResponseGateway> responseGateway = null;
		List<String> error = new ArrayList<>();
		RegistrationData resp = null;
		try
		{
			resp = userService.getLoginStatus(userName, password);
		
		if(null != resp)
		{
			
			responseGateway = gateway.buildResponse(resp, "", "200");
		}
		else
		{
			error.add("invalid credentials");
			responseGateway = gateway.buildResponse(error, "", "401");
		}
		}	
		catch(Exception e)
		{
		 //Exception handling
		 LOGGER.error(SocioAppConstants.API_ERROR, ExceptionUtils.getStackTrace(e));
		}
		LOGGER.info("Exit: getLoginStatus()");
		return responseGateway;
	}
	/**
	 * method searchUserName - to apply filters based on user name 
	 * @param name - name
	 * @param httpServletResponse - response
	 * @return ResponseEntity - entity
	 * @throws BaseClassException - exception
	 */
	@RequestMapping(value="/user/search/username", method= RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseGateway> searchUserName(
			@RequestParam String name,
			HttpServletResponse httpServletResponse) throws BaseClassException
	{
		LOGGER.info("searchUserName() api is invoked");
		ResponseGateway gateway = new ResponseGateway();
		ResponseEntity<ResponseGateway> responseGateway = null;
		List<String> error = new ArrayList<>();
		List<RegistrationData> resp = null;
		try
		{
			resp = userOperationRepository.searchUserByEmail(name);
		
		if(null != resp)
		{
			
			responseGateway = gateway.buildResponse(resp, "", "200");
		}
		else
		{
			error.add("No records");
			responseGateway = gateway.buildResponse(error, "", "200");
		}
		}	
		catch(Exception e)
		{
		 //Exception handling
		 LOGGER.error(SocioAppConstants.API_ERROR, ExceptionUtils.getStackTrace(e));
		}
		LOGGER.info("Exit: searchUserName()");
		return responseGateway;
	}
	/**
	 * method update user - to update user in DB
	 * @param registration - registration
	 * @param httpServletResponse - httpServletResponse
	 * @return response - response
	 * @throws BaseClassException - exception
	 */
	@RequestMapping(value="/{username}/forgot", method= RequestMethod.PUT, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseGateway> updateUser(@RequestBody Registration registration, 
			@PathVariable String username,
			HttpServletResponse httpServletResponse) throws BaseClassException
	{
		LOGGER.info("updateUser() api is invoked");
		ResponseGateway gateway = new ResponseGateway();
		ResponseEntity<ResponseGateway> responseGateway = null;
		List<String> error = new ArrayList<>();
		RegistrationData registrationData = null;
		try
		{
			registrationData = userService.updateUser(registration);
		
		if(null != registrationData)
		{
			responseGateway = gateway.buildResponse(registrationData, "", "200");
		}
		else
		{
			error.add("no records updated");
			responseGateway = gateway.buildResponse(error, "", "400");
		}
		}
		catch(Exception e)
		{
		 //Exception handling
		 LOGGER.error(SocioAppConstants.API_ERROR, ExceptionUtils.getStackTrace(e));
		}
		LOGGER.info("Exit: updateUser()");
		return responseGateway;
	}

}
