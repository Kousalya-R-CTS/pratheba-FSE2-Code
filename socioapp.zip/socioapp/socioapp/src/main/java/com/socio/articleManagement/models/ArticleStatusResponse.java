package com.socio.articleManagement.models;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ArticleStatusResponse {
	@JsonProperty("id")
    private String id;
    @JsonProperty("createdAt")
    private String created_at;
    @JsonProperty("authorId")
    private String author_id;
    @JsonProperty("text")
    private String text;
    @JsonProperty("userIdMention")
    private String user_id_mention;
    @JsonProperty("authorUserName")
    private String author_user_name;
    @JsonProperty("authorProfileUrl")
    private String author_profile_url;
    @JsonProperty("articleType")
    private String article_type;
    @JsonProperty("updatedAt")
    private String updated_at;
    @JsonProperty("isActive")
    private boolean isActive;
    @JsonProperty("mentionUserId")
    private String mention_user_id;
    @JsonProperty("articleId")
    private String article_id;
    @JsonProperty("userName")
    private String user_name;
    @JsonProperty("user")
    private RegistrationData user;
    @JsonProperty("eventType")
    private String event_type;
    @JsonProperty("mentions")
    private List<String> mentions;
    @JsonProperty("replyArticleList")
    private ReplyArticles reply_articles;
    @JsonProperty("favouriteArticles")
    private FavouriteArticles favourite_articles;
    /**
     * No args constructor for use in serialization
     * 
     */
    public ArticleStatusResponse() {
    	//Default constructor
    }
	/**
	 * @return the id
	 */
	@JsonProperty("id")
	public String getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	@JsonProperty("id")
	public void setId(String id) {
		this.id = id;
	}
	/**
	 * @return the created_at
	 */
	@JsonProperty("createdAt")
	public String getCreated_at() {
		return created_at;
	}
	/**
	 * @param created_at the created_at to set
	 */
	@JsonProperty("createdAt")
	public void setCreated_at(String created_at) {
		this.created_at = created_at;
	}
	/**
	 * @return the author_id
	 */
	@JsonProperty("authorId")
	public String getAuthor_id() {
		return author_id;
	}
	/**
	 * @param author_id the author_id to set
	 */
	@JsonProperty("authorId")
	public void setAuthor_id(String author_id) {
		this.author_id = author_id;
	}
	/**
	 * @return the text
	 */
	@JsonProperty("text")
	public String getText() {
		return text;
	}
	/**
	 * @param text the text to set
	 */
	@JsonProperty("text")
	public void setText(String text) {
		this.text = text;
	}
	/**
	 * @return the user_id_mention
	 */
	@JsonProperty("userIdMention")
	public String getUser_id_mention() {
		return user_id_mention;
	}
	/**
	 * @param user_id_mention the user_id_mention to set
	 */
	@JsonProperty("userIdMention")
	public void setUser_id_mention(String user_id_mention) {
		this.user_id_mention = user_id_mention;
	}
	/**
	 * @return the author_user_name
	 */
	@JsonProperty("authorUserName")
	public String getAuthor_user_name() {
		return author_user_name;
	}
	/**
	 * @param author_user_name the author_user_name to set
	 */
	@JsonProperty("authorUserName")
	public void setAuthor_user_name(String author_user_name) {
		this.author_user_name = author_user_name;
	}
	/**
	 * @return the author_profile_url
	 */
	@JsonProperty("authorProfileUrl")
	public String getAuthor_profile_url() {
		return author_profile_url;
	}
	/**
	 * @param author_profile_url the author_profile_url to set
	 */
	@JsonProperty("authorProfileUrl")
	public void setAuthor_profile_url(String author_profile_url) {
		this.author_profile_url = author_profile_url;
	}
	/**
	 * @return the article_type
	 */
	@JsonProperty("articleType")
	public String getArticle_type() {
		return article_type;
	}
	/**
	 * @param article_type the article_type to set
	 */
	@JsonProperty("articleType")
	public void setArticle_type(String article_type) {
		this.article_type = article_type;
	}
	/**
	 * @return the updated_at
	 */
	@JsonProperty("updatedAt")
	public String getUpdated_at() {
		return updated_at;
	}
	/**
	 * @param updated_at the updated_at to set
	 */
	@JsonProperty("updatedAt")
	public void setUpdated_at(String updated_at) {
		this.updated_at = updated_at;
	}
	/**
	 * @return the isActive
	 */
	@JsonProperty("isActive")
	public boolean isActive() {
		return isActive;
	}
	/**
	 * @param isActive the isActive to set
	 */
	@JsonProperty("isActive")
	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}
	
	/**
	 * @return the mention_user_id
	 */
	@JsonProperty("mentionUserId")
	public String getMention_user_id() {
		return mention_user_id;
	}
	/**
	 * @param mention_user_id the mention_user_id to set
	 */
	@JsonProperty("mentionUserId")
	public void setMention_user_id(String mention_user_id) {
		this.mention_user_id = mention_user_id;
	}
	/**
	 * @return the article_id
	 */
	@JsonProperty("articleId")
	public String getArticle_id() {
		return article_id;
	}
	/**
	 * @param article_id the article_id to set
	 */
	@JsonProperty("articleId")
	public void setArticle_id(String article_id) {
		this.article_id = article_id;
	}
	/**
	 * @return the user_name
	 */
	@JsonProperty("userName")
	public String getUser_name() {
		return user_name;
	}
	/**
	 * @param user_name the user_name to set
	 */
	@JsonProperty("userName")
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	/**
	 * @return the user
	 */
	@JsonProperty("user")
	public RegistrationData getUser() {
		return user;
	}
	/**
	 * @param user the user to set
	 */
	@JsonProperty("user")
	public void setUser(RegistrationData user) {
		this.user = user;
	}
	/**
	 * @return the event_type
	 */
	@JsonProperty("eventType")
	public String getEvent_type() {
		return event_type;
	}
	/**
	 * @param event_type the event_type to set
	 */
	@JsonProperty("eventType")
	public void setEvent_type(String event_type) {
		this.event_type = event_type;
	}
	/**
	 * @return the mentions
	 */
	@JsonProperty("mentions")
	public List<String> getMentions() {
		return mentions;
	}
	/**
	 * @param mentions the mentions to set
	 */
	@JsonProperty("mentions")
	public void setMentions(List<String> mentions) {
		this.mentions = mentions;
	}
	/**
	 * @return the reply_articles
	 */
	@JsonProperty("replyArticleList")
	public ReplyArticles getReply_articles() {
		return reply_articles;
	}
	/**
	 * @param reply_articles the reply_articles to set
	 */
	@JsonProperty("replyArticleList")
	public void setReply_articles(ReplyArticles reply_articles) {
		this.reply_articles = reply_articles;
	}
	/**
	 * @return the favourite_articles
	 */
	@JsonProperty("favouriteArticles")
	public FavouriteArticles getFavourite_articles() {
		return favourite_articles;
	}
	/**
	 * @param favourite_articles the favourite_articles to set
	 */
	@JsonProperty("favouriteArticles")
	public void setFavourite_articles(FavouriteArticles favourite_articles) {
		this.favourite_articles = favourite_articles;
	}
    

}
