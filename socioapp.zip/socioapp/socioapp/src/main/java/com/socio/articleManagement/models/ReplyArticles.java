
package com.socio.articleManagement.models;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ReplyArticles {

    @JsonProperty("replyCount")
    private int replyCount;
    @JsonProperty("threadId")
    private String threadId;
    @JsonProperty("replyArticles")
    private List<ReplyArticle> replyArticles;
    
    /**
     * No args constructor for use in serialization
     * 
     */
    public ReplyArticles() {
    }
    
	public ReplyArticles(int replyCount, String threadId, List<ReplyArticle> replyArticles) {
		super();
		this.replyCount = replyCount;
		this.threadId = threadId;
		this.replyArticles = replyArticles;
	}

	/**
	 * @return the replyCount
	 */
	@JsonProperty("replyCount")
	public int getReplyCount() {
		return replyCount;
	}

	/**
	 * @param replyCount the replyCount to set
	 */
	@JsonProperty("replyCount")
	public void setReplyCount(int replyCount) {
		this.replyCount = replyCount;
	}

	/**
	 * @return the threadId
	 */
	@JsonProperty("threadId")
	public String getThreadId() {
		return threadId;
	}

	/**
	 * @param threadId the threadId to set
	 */
	@JsonProperty("threadId")
	public void setThreadId(String threadId) {
		this.threadId = threadId;
	}

	/**
	 * @return the replyArticleList
	 */
	@JsonProperty("replyArticles")
	public List<ReplyArticle> getReplyArticleList() {
		return replyArticles;
	}

	/**
	 * @param replyArticleList the replyArticleList to set
	 */
	@JsonProperty("replyArticles")
	public void setReplyArticleList(List<ReplyArticle> replyArticleList) {
		this.replyArticles = replyArticleList;
	}

	
    
    

}
