package com.socio.articleManagement.models;

import java.util.List;

import javax.servlet.http.HttpServletResponse;

import com.socio.articleManagement.util.SocioAppConstants;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * Class Description
 * 
 *
 */
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class ResponseGateway
{
	/**
	 * field description
	 */
	private Object data;
	/**
	 * field description
	 */
	private String statusCode;
	/**
	 * field description
	 */
	private String status;
	/**
	 * field description
	 */
	private List<String> statusMessage;
	/**
	 * field description
	 */
	private String code;
	/**
	 * field description
	 */
	private ErrorResponse error;
	/**
	 * field description
	 */
	private List<String> errorSummary;
	/**
	 * field description
	 */
	private String errorCode;
	/**
	 * default Constructor
	 */
	public ResponseGateway() {
		super();
	}
	/**
	 * method description
	 */
	public Object getData() {
		return data;
	}
	/**
	 * method description
	 */
	public void setData(Object data) {
		this.data = data;
	}
	/**
	 * method description
	 */
	public String getStatusCode() {
		return statusCode;
	}
	/**
	 * method description
	 */
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	/**
	 * method description
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * method description
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * method description
	 */
	public List<String> getStatusMessage() {
		return statusMessage;
	}
	/**
	 * method description
	 */
	public void setStatusMessage(List<String> statusMessage) {
		this.statusMessage = statusMessage;
	}
	/**
	 * method description
	 */
	public String getCode() {
		return code;
	}
	/**
	 * method description
	 */
	public void setCode(String code) {
		this.code = code;
	}
	/**
	 * method description
	 */
	public ErrorResponse getError() {
		return error;
	}
	/**
	 * method description
	 */
	public void setError(ErrorResponse error) {
		this.error = error;
	}
	/**
	 * method description
	 */
	public List<String> getErrorSummary() {
		return errorSummary;
	}
	/**
	 * method description
	 */
	public void setErrorSummary(List<String> errorSummary) {
		this.errorSummary = errorSummary;
	}
	/**
	 * method description
	 */
	public String getErrorCode() {
		return errorCode;
	}
	/**
	 * method description
	 */
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	
	public ResponseEntity<ResponseGateway> buildResponse(Object data, String status,
			String statusCode)
	{
		ResponseEntity<ResponseGateway> response = new ResponseEntity<ResponseGateway>(this, HttpStatus.OK);
		this.setData(data);
		this.setStatus(status);
		this.setStatusCode(statusCode);
		return response;
	}
	public ResponseEntity<ResponseGateway> buildErrorResponse(HttpServletResponse httpServletResponse)
	{
		ResponseEntity<ResponseGateway> response = null;
		if(httpServletResponse.getStatus() == SocioAppConstants.HTTPSTATUS_BAD_REQUEST)
		{
			response = new ResponseEntity<ResponseGateway>(this, HttpStatus.BAD_REQUEST);
		}
		else if(httpServletResponse.getStatus() == SocioAppConstants.HTTPSTATUS_OK)
		{
			response = new ResponseEntity<ResponseGateway>(this, HttpStatus.OK);
		}
		else if(httpServletResponse.getStatus() == SocioAppConstants.HTTPSTATUS_NOT_FOUND)
		{
			response = new ResponseEntity<ResponseGateway>(this, HttpStatus.NOT_FOUND);
		}
		else if(httpServletResponse.getStatus() == SocioAppConstants.HTTPSTATUS_UN_AUTHORIZED)
		{
			response = new ResponseEntity<ResponseGateway>(this, HttpStatus.UNAUTHORIZED);
		}
		else 
		{
			response = new ResponseEntity<ResponseGateway>(this, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}
	
	
}
