package com.socio.articleManagement.repository;

import static org.junit.Assert.assertNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoTemplate;

import com.socio.articleManagement.exception.BaseClassException;
import com.socio.articleManagement.models.Registration;
import com.socio.articleManagement.models.RegistrationData;

@RunWith(MockitoJUnitRunner.Silent.class)
public class UserRepositoryTest
{
	@Mock
	private MongoTemplate mongoTemplate;
	
	@InjectMocks
	private UserRepository repository;
	
	@Test
	public void saveUser() throws BaseClassException
	{
		Registration registration = new Registration();
		Mockito.when(mongoTemplate.save(new RegistrationData(), "user_detail")).thenReturn(new RegistrationData());
		assertNull(repository.saveUser(registration));
	}
	@Test
	public void saveUserException() throws BaseClassException
	{
		Registration registration = new Registration();
		Mockito.when(mongoTemplate.save(null,null)).thenReturn(new NullPointerException());
		assertNull(repository.saveUser(registration));
	}

	@Test
	public void updateUser() throws BaseClassException
	{
		Registration registration = new Registration();
		Mockito.when(mongoTemplate.findAndModify(null, null, 
				new FindAndModifyOptions().returnNew(true), RegistrationData.class)).thenReturn(new RegistrationData());
		assertNull(repository.updateUser(registration));
	}
	

	@Test
	public void loginUser() throws BaseClassException
	{
		Mockito.when(mongoTemplate.findOne(null, RegistrationData.class)).thenReturn(new RegistrationData());
		assertNull(repository.getLoginStatus(null, null));
	}
	
}
