package com.socio.articleManagement.webservices;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.text.ParseException;
import java.util.ArrayList;

import com.socio.articleManagement.service.IArticleService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.ResponseEntity;

import com.socio.articleManagement.exception.BaseClassException;
import com.socio.articleManagement.models.ResponseGateway;
import com.socio.articleManagement.models.ArticleStatusResponse;
import com.socio.articleManagement.models.ArticleStatusResponseDB;
import com.socio.articleManagement.repository.ArticleOperationRepository;

@RunWith(MockitoJUnitRunner.Silent.class)
public class ArticleControllerTest {
	@Mock
	private ArticleOperationRepository tweetRepository;
	/**
	 * holds tweetService reference
	 */
	@Mock
	private IArticleService tweetService;
	
	@InjectMocks
	private ArticleController articleController;
	@Test
	public void saveTweets() throws BaseClassException, ParseException
	{
		Mockito.when(tweetService.saveArticles(null)).thenReturn(new ArticleStatusResponse());
		ResponseEntity<ResponseGateway> res = articleController.saveArticles(null, null, null);
		assertNotNull(res);
	}
	@Test
	public void saveTweetsException() throws BaseClassException, ParseException
	{
		articleController.setArticleService(null);
		ResponseEntity<ResponseGateway> res = articleController.saveArticles(null, null, null);
		assertNull(res);
	}
	@Test
	public void updateTweets() throws BaseClassException, ParseException
	{
		Mockito.when(tweetService.updateArticles(null)).thenReturn(new ArticleStatusResponse());
		ResponseEntity<ResponseGateway> res = articleController.updateArticles(null, null, null,null);
		assertNotNull(res);
	}
	@Test
	public void updateTweetsException() throws BaseClassException, ParseException
	{
		articleController.setArticleService(null);
		ResponseEntity<ResponseGateway> res = articleController.updateArticles(null, null, null, null);
		assertNull(res);
	}
	@Test
	public void favouriteTest() throws BaseClassException, ParseException
	{
		Mockito.when(tweetService.favouriteArticles(null, null)).thenReturn(new ArticleStatusResponse());
		ResponseEntity<ResponseGateway> res = articleController.favouriteArticles(null, null, null,null);
		assertNotNull(res);
	}
	@Test
	public void favouriteTestException() throws BaseClassException, ParseException
	{
		articleController.setArticleService(null);
		ResponseEntity<ResponseGateway> res = articleController.favouriteArticles(null, null, null, null);
		assertNull(res);
	}
	@Test
	public void replyTest() throws BaseClassException, ParseException
	{
		Mockito.when(tweetService.replyArticles(null)).thenReturn(new ArticleStatusResponse());
		ResponseEntity<ResponseGateway> res = articleController.replyArticles(null, null, null,null);
		assertNotNull(res);
	}
	@Test
	public void replyTestException() throws BaseClassException, ParseException
	{
		articleController.setArticleService(null);
		ResponseEntity<ResponseGateway> res = articleController.replyArticles(null, null, null, null);
		assertNull(res);
	}
	@Test
	public void searchTest() throws BaseClassException, ParseException
	{
		Mockito.when(tweetService.getUserArticles(null, null, null)).thenReturn(new ArrayList<ArticleStatusResponseDB>());
		ResponseEntity<ResponseGateway> res = articleController.getUserArticles(null, null, null,null);
		assertNotNull(res);
	}
	@Test
	public void searchTestException() throws BaseClassException, ParseException
	{
		articleController.setArticleService(null);
		ResponseEntity<ResponseGateway> res = articleController.getUserArticles(null, null, null, null);
		assertNull(res);
	}
	@Test
	public void deleteTest() throws BaseClassException, ParseException
	{
		Mockito.when(tweetService.deleteArticle(null, null)).thenReturn(true);
		ResponseEntity<ResponseGateway> res = articleController.deleteArticle(null, null, null);
		assertNotNull(res);
	}
	@Test
	public void deleteTestFalse() throws BaseClassException, ParseException
	{
		Mockito.when(tweetService.deleteArticle(null, null)).thenReturn(false);
		ResponseEntity<ResponseGateway> res = articleController.deleteArticle(null, null, null);
		assertNotNull(res);
	}
	@Test
	public void deleteTestException() throws BaseClassException, ParseException
	{
		articleController.setArticleService(null);
		ResponseEntity<ResponseGateway> res = articleController.deleteArticle(null, null, null);
		assertNull(res);
	}
	@Test
	public void searchAllTest() throws BaseClassException, ParseException
	{
		
		Mockito.when(tweetRepository.findAll()).thenReturn(new ArrayList<ArticleStatusResponseDB>());
		ResponseEntity<ResponseGateway> res = articleController.searchAllArticles(null);
		assertNotNull(res);
	}
	@Test
	public void searchAllTestException() throws BaseClassException, ParseException
	{
		articleController.setArticleService(null);
		ResponseEntity<ResponseGateway> res = articleController.searchAllArticles(null);
		assertNotNull(res);
	}
}
