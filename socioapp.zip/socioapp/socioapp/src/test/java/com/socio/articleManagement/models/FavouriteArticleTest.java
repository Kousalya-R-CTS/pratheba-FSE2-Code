package com.socio.articleManagement.models;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.meanbean.test.BeanTester;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.Silent.class)
public class FavouriteArticleTest {

	
	@Test
	public void favouriteTweetTest()
	{
		new BeanTester().testBean(FavouriteArticle.class);
		assertNotNull(new FavouriteArticle());
	}
	
}
