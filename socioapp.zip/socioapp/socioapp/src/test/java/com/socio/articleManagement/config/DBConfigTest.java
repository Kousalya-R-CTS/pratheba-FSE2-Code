package com.socio.articleManagement.config;


import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.Silent.class)
public class DBConfigTest {

	@InjectMocks
	private DBConfig config;
	
	@Test
	public void mongoClient()
	{
		assertNotNull(config.mongoClient());
	}
	@Test
	public void mongoTemplate()
	{
		assertNotNull(config.mongoTemplate());
	}
	
}
