package com.socio.articleManagement.models;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.meanbean.test.BeanTester;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.Silent.class)
public class RegistrationTest {

	
	@Test
	public void registrationTest()
	{
		new BeanTester().testBean(Registration.class);
		assertNotNull(new Registration());
	}
	
}
