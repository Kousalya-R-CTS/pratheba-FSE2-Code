package com.socio.articleManagement.config;


import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.Silent.class)
public class SwaggerConfigTest {

	@InjectMocks
	private SwaggerConfig config;
	
	@Test
	public void productApi()
	{
		assertNotNull(config.productApi());
	}
	
}
