package com.socio.articleManagement.models;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.meanbean.test.BeanTester;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.Silent.class)
public class ReplyArticlesTest {

	
	@Test
	public void replyTweetsTest()
	{
		new BeanTester().testBean(ReplyArticles.class);
		assertNotNull(new ReplyArticles());
	}
	
}
