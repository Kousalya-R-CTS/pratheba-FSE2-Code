package com.socio.articleManagement.models;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.meanbean.test.BeanTester;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.Silent.class)
public class ErrorResponseTest {

	
	@Test
	public void errorResponseTest()
	{
		new BeanTester().testBean(ErrorResponse.class);
		assertNotNull(new ErrorResponse());
	}
	
}
