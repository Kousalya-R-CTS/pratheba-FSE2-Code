package com.socio.articleManagement.impl;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.socio.articleManagement.exception.BaseClassException;
import com.socio.articleManagement.models.Registration;
import com.socio.articleManagement.models.RegistrationData;
import com.socio.articleManagement.repository.UserRepository;

@RunWith(MockitoJUnitRunner.Silent.class)
public class UserServiceImplTest {
	/**
	 * holds userRepository reference
	 */
	@Mock
	private UserRepository userRepository;
	@InjectMocks
	private UserServiceImpl userServiceImpl;
	
	
	
	@Test
	public void saveUserTest() throws BaseClassException
	{
		RegistrationData registration = new RegistrationData();
		Registration reg = new Registration();
		Mockito.when(userRepository.saveUser(reg)).thenReturn(registration);
		assertNotNull(userServiceImpl.saveUser(reg));
	}
	@Test
	public void updateUserTest() throws BaseClassException
	{
		RegistrationData registration = new RegistrationData();
		Registration reg = new Registration();
		Mockito.when(userRepository.updateUser(reg)).thenReturn(registration);
		assertNotNull(userServiceImpl.updateUser(reg));
	}
	@Test
	public void getLoginTest() throws BaseClassException
	{
		RegistrationData registration = new RegistrationData();
		Mockito.when(userRepository.getLoginStatus(null, null)).thenReturn(registration);
		assertNotNull(userServiceImpl.getLoginStatus(null, null));
	}

}
