import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ServiceConstants } from '../constants/serviceConstants';
import { Article } from '../models/article';
import { ArticleResponse } from '../models/articleResponse';

@Injectable({
  providedIn: 'root'
})
export class ArticleService {
  url = ServiceConstants.apiURL;
  constructor(private http: HttpClient) {

   }

   getUserArticles(loginUserName : String, id : String, threadId : String, createdAt : String)
   {
    var tempUrl = this.url   + ServiceConstants.userArticleEndPoint; 

    if(id != '') 
    {
      tempUrl = tempUrl + '?' + 'id='+ id + '&' + 'createdAt=' + createdAt;
    }
    if(loginUserName != '')
    {
      tempUrl = tempUrl + '?' + 'name=' + loginUserName;
    }
    if(threadId != '')
    {
      tempUrl = tempUrl + '?' + 'threadId=' + threadId;
    }
    
    return this.http.get<ArticleResponse>(tempUrl);
   }
   replyArticleSave(user : Article)
   {
     var tempUrl = this.url + sessionStorage.getItem('username') + '/' + 'reply' + '/' + user.articleId;
     return this.http.post(tempUrl,user);
   }
   updateArticle(user : Article)
   {
     var tempUrl = this.url + sessionStorage.getItem('username') + '/' + 'update' + '/' + user.articleId;
     return this.http.put(tempUrl, user);
   }
   deleteArticle(user : Article)
   {
     var tempUrl = this.url + sessionStorage.getItem('username') + '/' + 'delete' + '/' + user.articleId;
     return this.http.delete(tempUrl);
   }
   saveArticle(user : Article)
   {
     var tempUrl = this.url + sessionStorage.getItem('username') + '/' + 'add';
     return this.http.post(tempUrl,user);
   }
   favoriteArticles(name : string, id: string, Article : Article)
   {
    var tempUrl = this.url   + name + ServiceConstants.likeEndPoint + id;
    return this.http.put(tempUrl, Article);
   }
   getAllArticles()
   {
     var tempUrl = this.url + 'all';
     return this.http.get<ArticleResponse>(tempUrl);
   }
}
