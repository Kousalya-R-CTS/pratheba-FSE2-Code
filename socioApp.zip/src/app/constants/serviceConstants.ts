export class ServiceConstants
 {

    public static apiURL: string = "http://localhost:8082/api/v1.0/articles/";

      

    public static loginEndPoint : string = "login";
    public static resetEndPoint : string = "forgot";
    public static userArticleEndPoint : string = "username";
    public static likeEndPoint : string = "/like/";
    public static searchUserArticleUrl : string = "user/search/";
    public static paramName : string ="name=";

}