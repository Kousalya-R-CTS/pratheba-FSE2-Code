import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { UserService } from '../../services/user.service';
import { Data } from '../../models/data';
import { Result } from 'src/app/models/result';
import { Router } from '@angular/router';
export class Todo {
  constructor(
    public data: Data,
   public statusCode : any
  ){}

}

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
    submitted = false;
    todo: Result = new Result;
    todos: Result = new Result;
    listod: Data[] = [];
    loginError: boolean = false;
  loginForm = new FormGroup({
    userName: new FormControl(''),
    password: new FormControl(''),
  });
   
  constructor(private formBuilder: FormBuilder, private userService : UserService,private router : Router,private http: HttpClient) { }

  ngOnInit(): void {
    this.loginError = false;
    //If user logout remove username
    sessionStorage.removeItem('username');
    this.loginForm = this.formBuilder.group({
      userName: ['', [Validators.required]],
      password: ['', [Validators.required, Validators.minLength(6),Validators.maxLength(13) ]]
  });
  //if user type input then validation error will not be shown
  this.loginForm.valueChanges.subscribe(() => {
    this.loginError = false;
  });
  }
  // convenience getter for easy access to form fields
  get f() { return this.loginForm.controls; }
  register()
  {
    this.router.navigate(['login']);
  }
 //After submit form
  onSubmit(dataValue : any) {
     if(this.loginForm.dirty)
      {
        this.loginError = false;
      }
      this.submitted = true;
      
      // stop here if form is invalid
      if (this.loginForm.invalid) {
          return;
      }
      else if(this.loginForm.valid)
      {
        //check user credentials
        this.userService.checkLogin(dataValue.userName,dataValue.password).subscribe
        (data => {if(data.statusCode == '200')
        {
          sessionStorage.setItem('username', dataValue.userName);
          this.router.navigate(['home', dataValue.userName]);
        }
        else{
          this.loginError = true;
        }});
      
      }
     
  }

}
