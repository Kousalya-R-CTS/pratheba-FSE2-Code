import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, UrlSegment } from '@angular/router';
import { Data } from 'src/app/models/data';
import {MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { Article } from 'src/app/models/article';
import { articles } from 'src/app/models/articles';
import { ArticleService } from 'src/app/services/article.service';
import { UserService } from 'src/app/services/user.service';
import { MaterialDialogReplyArticleComponent } from '../material-dialog-reply-article/material-dialog-reply-article.component';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {
  
  isLoad : boolean = true;
   isUser : boolean = false;
   profileName : string = ''
   isArticles : boolean = false;
  userNames: String[] = [];
  ArticleList : Article[] = [];
  likeCount : number =0;
  hidden = false;
  id : any =  '';
  showArticleEmpty = false;
  user : Data = new Data('','','','','','');
  ArticleResponse: articles = new articles(new Array<Article>());
  constructor( private userService : UserService,private dialog : MatDialog,private route: ActivatedRoute,private ArticleService : ArticleService,private router : Router) { }

  ngOnInit(): void {
   this.id = sessionStorage.getItem("username");
    this.isUser = true;
    this.isArticles = false;
    this.isLoad = true;
    this.showArticleEmpty = false;
    /**
     * To view list of users in users page
     */
    this.userService.getUserId().subscribe(data =>{
      this.isLoad = false;
      this.userNames = data.data;
     
    });
    
    
  } 
  /**
   * For profiling purpose get user details
   * @param user - any
   */
  viewUser(user: any)
  {
    this.userService.searchUserName(user).subscribe(data => {
      this.user = data.data[0];
    });
  }
  //Delete Articles
  deleteArticle(user : Article)
  {
    this.ArticleService.deleteArticle(user).subscribe(data => (
      this.viewProfile(this.profileName)
    ));
  }
  //update Articles
  updateArticles(user : Article)
  {
    user.eventType = 'UPDATEArticle';
   this.openDialog(user); 
  }
  /**
   * to view Articles of a user 
   * @param user 
   */
  viewProfile(user : any)
  {
    this.profileName = user;
    this.ArticleService.getUserArticles(user,'','','').subscribe(data => {
      this.isUser = false;
      this.isArticles = true;
      this.ArticleResponse.articles = data.data.articles;
      this.isLoad = false;
      if(data.data.metaData.resultCount == 0)
      {
        this.showArticleEmpty = true;
      }
      this.ArticleList = this.ArticleResponse.articles;
      });
  }
  /**
   * To upvote/like the Article
   * @param user 
   */
  favourites(user : Article)
  {
    var isLike = false;
    user.eventType = 'LIKE';
   
    //For prevent more likes by  user who already liked that Article
    if(undefined != user.favouriteArticles && null != user.favouriteArticles)
    {
      for(var i =0 ;i< user.favouriteArticles.favouriteArticleList.length;i++)
      {
        if(user.favouriteArticles.favouriteArticleList[i].favouriteUserName == this.id)
        {
          isLike = true;
        }
      }
    }
    if(!isLike)
    {
      this.ArticleService.favoriteArticles(this.id, user.articleId, user).subscribe(data =>
      { 
      this.viewProfile(this.profileName);
      });
      
    }
    
   
  }
  /**
   * To reply Article
   * @param user 
   */
  replyArticles(user : Article)
  {
    this.openDialog(user);
    if(undefined != user.replyArticleList || null != user.replyArticleList)
    {
      this.ArticleService.getUserArticles('',user.articleId, '', user.createdAt).subscribe(data=> {
      });
    }
  }
  openDialog(user : Article) {
    const dialogRef = this.dialog.open(MaterialDialogReplyArticleComponent, {
      width : '750px', height : '500px',
      data: user, restoreFocus: false});

    // Manually restore focus to the menu trigger since the element that
    // opens the dialog won't be in the DOM any more when the dialog closes.
    dialogRef.afterClosed().subscribe(() => this.viewProfile(this.profileName));
  }
  

}
