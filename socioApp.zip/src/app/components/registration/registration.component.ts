import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  Validators,
  FormControl
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { UserService } from '../../services/user.service';
import { Router } from '@angular/router';
import { Data } from '../../models/data';
import { Userresponse } from 'src/app/models/userresponse';
import { MatDialog } from '@angular/material/dialog';
import { MaterialDialogComponent } from '../material-dialog/material-dialog.component';
import { Model } from 'src/app/models/model';
@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css'],
})
export class RegistrationComponent implements OnInit {
  resp: Userresponse = new Userresponse([]);
  arr: String[] = [];
  model: Model = new Model();
  registerForm = new FormGroup({
    firstName: new FormControl(''),
    lastName: new FormControl(''),
    email: new FormControl(''),
    userName: new FormControl(''),
    password: new FormControl(''),
    confirmPassword: new FormControl(''),
    mobileNumber: new FormControl(''),
  });
  userNameError = false;
  loginError = false;
  submitted = false;
  userId: String[] = [];
  register: Data = new Data('', '', '', '', '', '');
  constructor(
    private formBuilder: FormBuilder,
    private matDialog: MatDialog,
    private userService: UserService,
    private router: Router,
    private http: HttpClient
  ) {}

  ngOnInit(): void {
    this.userNameError = false;
    //For unique id validation
    this.userService.getUserId().subscribe((data) => {
      this.userId = data.data;
    });
    this.resp = new Userresponse(this.userId);
    this.loginError = false;
    this.registerForm = this.formBuilder.group(
      {
        firstName: ['', Validators.required],
        lastName: ['', Validators.required],
        email: ['', [Validators.required, Validators.email]],
        userName: ['', [Validators.required]],
        password: ['', [Validators.required, Validators.minLength(6)]],
        confirmPassword: ['', Validators.required],
        mobileNumber: [
          '',
          [
            Validators.required,
            Validators.pattern('^((\\+91-?)|0)?[0-9]{10}$'),
          ],
        ],
      },
      {
        validator: MustMatch('password', 'confirmPassword'),
      }
    );
    this.registerForm.valueChanges.subscribe(() => {
      this.loginError = false;

      this.userNameError = false;
    });
  }
  // convenience getter for easy access to form fields
  get f() {
    return this.registerForm.controls;
  }
  onSubmit(dataValue: any) {
    if (this.registerForm.dirty) {
      this.userNameError = false;
      this.loginError = false;
    }
    var check = this.getUserNames(
      this.userId,
      dataValue.userName
    );
    this.submitted = true;
    if (check) {
      this.userNameError = true;
    }
    // stop here if form is invalid
    if (this.registerForm.invalid) {
      return;
    }
    //if valid means check validation and call service api
     else if (this.registerForm.valid && check == null) {
      this.register = new Data(
        dataValue.firstName,
        dataValue.lastName,
        dataValue.userName,
        dataValue.mobileNumber,
        dataValue.email,
        dataValue.password
      );

      this.userService.createUser(this.register)
        .subscribe((data) => {
          this.registerForm.reset();
          this.submitted = false;
          this.openDialog();
        });
    }
  }
  /**
   * To check whether user id is  unique or not
   * @param arr 
   * @param value 
   * @returns 
   */
  getUserNames(arr: String[], value: String) {
    var isUnique = false;

    if (arr != undefined && !(arr.length == 0)) {
      for (var i = 0; i < arr.length; i++) {
        if (arr[i] == value) {
          isUnique = true;
        }
      }
      if (isUnique) {
        return true;
      } else {
        return null;
      }
    }
    return null;
  }
  //For succes message 
  openDialog() {
    this.model.content =
      'Registration is success. Please login with your credentials';
    this.model.title = 'Registration';
    const dialogRef = this.matDialog.open(MaterialDialogComponent, {
      width: '450px',
      height: '200px',
      data: this.model,
      restoreFocus: false,
    });
    // Manually restore focus to the menu trigger since the element that
    // opens the dialog won't be in the DOM any more when the dialog closes.
    dialogRef.afterClosed().subscribe(() => this.router.navigate(['login']));
  }
}

// custom validator to check that two fields match in password and confirm password
export function MustMatch(controlName: string, matchingControlName: string) {
  return (formGroup: FormGroup) => {
    const control = formGroup.controls[controlName];
    const matchingControl = formGroup.controls[matchingControlName];

    if (matchingControl.errors && !matchingControl.errors.mustMatch) {
      // return if another validator has already found an error on the matchingControl
      return;
    }

    // set error on matchingControl if validation fails
    if (control.value !== matchingControl.value) {
      matchingControl.setErrors({ mustMatch: true });
    } else {
      matchingControl.setErrors(null);
    }
  };
}
