import { Component, OnInit,Inject } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Model } from 'src/app/models/model';

@Component({
  selector: 'app-material-dialog',
  templateUrl: './material-dialog.component.html',
  styleUrls: ['./material-dialog.component.css']
})
export class MaterialDialogComponent implements OnInit {

  constructor(@Inject(MAT_DIALOG_DATA) public content: Model) { }

  ngOnInit(): void {
  }

}
