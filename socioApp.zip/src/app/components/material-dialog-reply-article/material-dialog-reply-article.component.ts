import { Component, OnInit,Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Article } from 'src/app/models/article';
import { ArticleService } from 'src/app/services/article.service';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { UserService } from 'src/app/services/user.service';
import { Data } from 'src/app/models/data';

@Component({
  selector: 'app-material-dialog-reply-Article',
  templateUrl: './material-dialog-reply-Article.component.html',
  styleUrls: ['./material-dialog-reply-Article.component.css']
})
export class MaterialDialogReplyArticleComponent implements OnInit {
  userId : String[] =[];
  loginDetail : Data = new Data('','','','','','');
  Articles: Article[] = [];
  replyArticle : Article = new Article();
  originArticle : Article[] = [];
  id : any ;
  isLoad = false;
  submitted = false;
  ArticleForm = new FormGroup({
    ArticleText: new FormControl(''),
   
  });
  constructor(@Inject(MAT_DIALOG_DATA) public user: Article,private formBuilder: FormBuilder, private route: ActivatedRoute,
  private dialogRef: MatDialogRef<MaterialDialogReplyArticleComponent>, private ArticleService : ArticleService,
  private userService : UserService) { }

  ngOnInit(): void {
    this.id= sessionStorage.getItem('username');
    //Loading indicator
    this.isLoad = false;
    this.submitted = false;
    //for get login user details for author 
    this.viewUser(this.id);
    this.userService.getUserId().subscribe(data => {
      this.userId = data.data;
    })
    this.ArticleForm = this.formBuilder.group({
      ArticleText: ['', [Validators.maxLength(144),Validators.minLength(1)]]
  });
  //For update Article
  if(this.user.eventType == 'UPDATEArticle')
  {
    //for save update
    this.updateArticles();
  }
  //For reply Articles
  else
  {
    //show previous reply
    this.replyArticles();
  }
}
  // convenience getter for easy access to form fields
  get f() { return this.ArticleForm.controls; }
  onSubmit(formValue : any)
  {
    this.submitted = true;
    // stop here if form is invalid
    if (this.ArticleForm.invalid) {
        return;
    }
    else if(this.ArticleForm.valid && formValue.ArticleText.length > 0)
    {
      this.isLoad = true;
      /**
       * For update Article - have to update only text content
       */
      if(this.user.eventType == 'UPDATEArticle')
      {
        this.user.text = formValue.ArticleText;
        this.user.eventType = 'UPDATE';
        this.ArticleService.updateArticle(this.user).subscribe(data => {
          this.isLoad = false;
      this.dialogRef.close();
        })
      }
      /**
       * For reply Articles - save as new Article and append reply Articles to thread 
       */
      else{
        this.replyArticle.articleId =this.user.articleId;
        this.replyArticle.text = formValue.ArticleText;
        this.replyArticle.articleType = 'REPLY';
        this.replyArticle.authorUserName = this.id;
        this.replyArticle.eventType = 'UPDATE';
        this.replyArticle.userName = this.user.authorUserName; 
        this.replyArticle.user = this.loginDetail;
        //For service call
        this.ArticleService.replyArticleSave(this.replyArticle).subscribe(data => {          
        this.isLoad = false;
        this.dialogRef.close();
      });
    }
   
    }
  }
   /**
   * For profiling purpose get user details
   * @param user - any
   */
    viewUser(user: any)
    {
      this.userService.searchUserName(user).subscribe(data => {
        this.loginDetail = data.data[0];
      });
    }
    //For reply Articles show original Article if exist
  replyArticles()
  {
    if(undefined != this.user.replyArticleList || null != this.user.replyArticleList)
    {
      //passed as id to get reply Articles for that Article
      this.ArticleService.getUserArticles('',this.user.articleId,'',this.user.createdAt).subscribe(data=> {
        this.Articles = data.data.articles;
      });
    }
    if(undefined != this.user.articleType && 'REPLY' == this.user.articleType)
    {
      //passed as thread id to get original Articles
      this.ArticleService.getUserArticles('','',this.user.articleId,'').subscribe(data => {
        this.originArticle = data.data.articles;
      })
    }
  }
  //For update Article set prefilled old text content
  updateArticles()
  {
    this.ArticleForm.setValue({
      ArticleText : this.user.text
    })
  }

}
