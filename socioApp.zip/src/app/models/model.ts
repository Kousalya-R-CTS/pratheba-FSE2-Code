export class Model{
    content : string = '';
    title : string = '';
    
}