export class Data{
    id!: string;
    firstName : string;
    lastName : string;
    loginId : string;
    contactNumber : string;
    email : string;
    password : string;
    status: string = '';
    
    constructor(firstName:string, lastName: string,loginId:string,contactNumber:string,email:string,
        password:string)
    {
        this.email = email;
        this.firstName = firstName;
        this.lastName = lastName;
        this.loginId = loginId;
        this.contactNumber = contactNumber;
        this.password = password;
        
    }
}