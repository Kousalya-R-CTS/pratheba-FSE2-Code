import { ReplyArticle } from "./replyArticle";

export class ReplyArticles 
{
    replyCount : number =0;
    threadId : String = '';
    replyArticles: ReplyArticle[] = [];
    constructor(data : ReplyArticle[])
    {
        this.replyArticles = data;
    }
}