export class FavouriteArticle{
    createdAt : String = '';
    favouriteAt : String = '';
    isLike : boolean = true;
    id : String = '';
    articleId : String = '';
    favouriteUserName : String = '';
   
}