import { Data } from "./data";

export class Result {
   data: Data[] = [];
   userNames : String[] = [];
   statusCode : any;
   
}