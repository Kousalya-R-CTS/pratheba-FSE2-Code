import { Data } from "./data";
import { FavouriteArticles } from "./favouriteArticles";
import { ReplyArticle } from "./replyArticle";
import { ReplyArticles } from "./replyArticles";


export class Article{
    createdAt : string = '';
    text : string = '';
    authorUserName : string = '';
    articleType : string = '';
    updatedAt : string = '';
    isActive : boolean = false;
    articleId : string = '';
    userName : string = '';
    user : Data = new Data('','','','','','');
    eventType : string = '';
    originalArticleId : string = '';
    replyCount : number =0 ;
    replyArticleList: ReplyArticles = new ReplyArticles([]);
    favouriteArticles: FavouriteArticles = new FavouriteArticles();
    

}