import { Metadata } from "./metaData";
import { Article } from "./article";

export class articles{
    metaData: Metadata = new Metadata;
    articles :  Article[] = [];
    constructor(articles : Array<Article>)
    {
        this.articles = articles;
    }
}